package net.bluecow.spectro.painting;

public abstract interface PlaybackPositionListener
{
  public abstract void playbackPositionUpdate(PlaybackPositionEvent paramPlaybackPositionEvent);
}

/* Location:           /Users/gigemjt/workspace/PumpAndJump/PumpAndJump/resources/spectro-edit_0.4 /
 * Qualified Name:     net.bluecow.spectro.PlaybackPositionListener
 * JD-Core Version:    0.6.1
 */