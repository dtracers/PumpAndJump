package net.bluecow.spectro;

public abstract interface WindowFunction
{
  public abstract void applyWindow(double[] paramArrayOfDouble);
}

/* Location:           /Users/gigemjt/workspace/PumpAndJump/PumpAndJump/resources/spectro-edit_0.4 /
 * Qualified Name:     net.bluecow.spectro.WindowFunction
 * JD-Core Version:    0.6.1
 */