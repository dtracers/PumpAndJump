package net.bluecow.spectro;

public class NullWindowFunction
  implements WindowFunction
{
  public void applyWindow(double[] data)
  {
  }
}

/* Location:           /Users/gigemjt/workspace/PumpAndJump/PumpAndJump/resources/spectro-edit_0.4 /
 * Qualified Name:     net.bluecow.spectro.NullWindowFunction
 * JD-Core Version:    0.6.1
 */