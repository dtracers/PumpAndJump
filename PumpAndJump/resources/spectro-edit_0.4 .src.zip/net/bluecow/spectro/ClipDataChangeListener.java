package net.bluecow.spectro;

public abstract interface ClipDataChangeListener
{
  public abstract void clipDataChanged(ClipDataChangeEvent paramClipDataChangeEvent);
}

/* Location:           /Users/gigemjt/workspace/PumpAndJump/PumpAndJump/resources/spectro-edit_0.4 /
 * Qualified Name:     net.bluecow.spectro.ClipDataChangeListener
 * JD-Core Version:    0.6.1
 */